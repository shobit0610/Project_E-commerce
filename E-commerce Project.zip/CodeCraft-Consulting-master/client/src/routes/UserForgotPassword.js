import React from "react";
import ForgotPasswordU from "../Access/User/ForgotPasswordU";

const UserForgotPassword = () =>{
    return(
        <div>
            <ForgotPasswordU/>
        </div>
    )
}

export default UserForgotPassword;