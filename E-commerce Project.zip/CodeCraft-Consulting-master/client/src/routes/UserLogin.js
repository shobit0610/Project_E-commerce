import React from "react";
import LoginU from "../Access/User/LoginU";

const UserLogin = () =>{
    return(
        <div>
            <LoginU/>
        </div>
    )
}

export default UserLogin;