import React from "react";
import ResetPasswordU from "../Access/User/ResetPasswordU";

const UserResetPassword = () =>{
    return(
        <div>
            <ResetPasswordU/>
        </div>
    )
}

export default UserResetPassword;