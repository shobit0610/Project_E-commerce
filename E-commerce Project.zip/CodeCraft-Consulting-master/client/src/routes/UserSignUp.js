import React from "react";
import SignUpU from "../Access/User/SignUpU";

const UserSignUp = () =>{
    return(
        <div>
            <SignUpU/>
        </div>
    )
}

export default UserSignUp;